# AEE Execution Wrapper Patch v0.1

This patch modifies only `scripts/verify_and_stage.py` in the already validated `AEE_POST_BUILD_EXECUTION_ENVIRONMENT_v0.1.zip`.

Base environment SHA-256:
`39fe56f758b3fddd58c22bf621b16e69eab7122359a6989bafa2163852dc1372`

Patched script SHA-256:
`d3a5d1012cffdf1abb559ec3b4224a661423fbeb9d925d64a7528982d92a14d2`

The implementation candidate, TCB, N144 fixtures, matrix, build gate, and FINAL_POLICY are not included and must remain byte-identical to the base environment.
