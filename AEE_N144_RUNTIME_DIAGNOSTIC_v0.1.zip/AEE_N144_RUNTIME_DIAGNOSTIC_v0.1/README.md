# AEE N144 Runtime Diagnostic v0.1

Non-authoritative localization probe. It does not modify or replace the frozen candidate. It independently reconstructs the v0.1.8 detached read-only tmpfs bundle projection on fd14 and invokes the exact frozen gh bytes with the exact frozen authority argv, subject, bundle and trusted root. Its only purpose is to distinguish projection/gh-runtime failure from a candidate-internal pre-exec control failure. A PASS here is not N144 PASS and confers no authority.

Run on the same privileged GitHub Actions host after extracting AEE_N144_EXECUTION_EVIDENCE.zip:

`sudo ./scripts/run_diagnostic.sh <extracted-evidence-root>`
