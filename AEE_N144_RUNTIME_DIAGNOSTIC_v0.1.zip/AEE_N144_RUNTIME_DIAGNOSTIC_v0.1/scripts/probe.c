#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

static void die(const char *stage){fprintf(stderr,"DIAG_FAIL:%s errno=%d (%s)\n",stage,errno,strerror(errno));exit(90);} 
static void ok(const char *stage){fprintf(stderr,"DIAG_PASS:%s\n",stage);} 

int main(int argc,char **argv){
 if(argc!=5){fprintf(stderr,"usage: probe GH SUBJECT BUNDLE ROOT\n");return 2;}
 const char *gh=argv[1],*subject=argv[2],*bundle=argv[3],*rootfile=argv[4];
 if(unshare(CLONE_NEWNS|CLONE_NEWNET)) die("unshare_newns_newnet"); ok("unshare_newns_newnet");
 if(mount(NULL,"/",NULL,MS_REC|MS_PRIVATE,NULL)) die("mount_private"); ok("mount_private");
 char mp[]="/tmp/aee-diag-XXXXXX"; if(!mkdtemp(mp)) die("mkdtemp");
 int base=open(mp,O_RDONLY|O_DIRECTORY|O_CLOEXEC|O_NOFOLLOW); if(base<0)die("open_mountpoint");
 char pp[64]; snprintf(pp,sizeof pp,"/proc/self/fd/%d",base);
 if(mount("aee-diag",pp,"tmpfs",MS_NOSUID|MS_NODEV|MS_NOEXEC,"size=80m,mode=0500"))die("mount_tmpfs"); ok("mount_tmpfs");
 int rfd=open(pp,O_RDONLY|O_DIRECTORY|O_CLOEXEC|O_NOFOLLOW); if(rfd<0)die("open_tmpfs_root");
 int in=open(bundle,O_RDONLY|O_CLOEXEC|O_NOFOLLOW); if(in<0)die("open_bundle");
 int out=openat(rfd,"bundle.json",O_WRONLY|O_CREAT|O_EXCL|O_CLOEXEC|O_NOFOLLOW,0400); if(out<0)die("create_bundle_json");
 char buf[8192]; for(;;){ssize_t n=read(in,buf,sizeof buf); if(n<0)die("read_bundle"); if(!n)break; char *p=buf; while(n){ssize_t w=write(out,p,n);if(w<0)die("write_bundle");p+=w;n-=w;}}
 if(fsync(out))die("fsync_bundle"); close(out);close(in);ok("copy_bundle");
 if(mount(NULL,pp,NULL,MS_REMOUNT|MS_RDONLY|MS_NOSUID|MS_NODEV|MS_NOEXEC,NULL))die("remount_ro");ok("remount_ro");
 if(dup2(rfd,14)<0)die("dup_root_fd14");ok("dup_root_fd14");
 if(umount2(pp,MNT_DETACH))die("detach_mount");close(rfd);close(base);if(rmdir(mp))die("rmdir_mountpoint");ok("detach_and_remove_path");
 int sfd=open(subject,O_RDONLY|O_CLOEXEC|O_NOFOLLOW);if(sfd<0)die("open_subject");if(dup2(sfd,10)<0)die("dup_subject_fd10");close(sfd);
 int tfd=open(rootfile,O_RDONLY|O_CLOEXEC|O_NOFOLLOW);if(tfd<0)die("open_root");if(dup2(tfd,12)<0)die("dup_root_fd12");close(tfd);
 ok("fixed_fds_ready");
 char *av[]={"gh","attestation","verify","/proc/self/fd/10","--repo","andrearomeo74-cloud/LIMEN-AEE","--signer-workflow","andrearomeo74-cloud/LIMEN-AEE/.github/workflows/aee_attest_probe.yml","--source-digest","24c17ccccc21029c5eed95917f429a7b688a6f83","--signer-digest","24c17ccccc21029c5eed95917f429a7b688a6f83","--source-ref","refs/heads/main","--cert-oidc-issuer","https://token.actions.githubusercontent.com","--predicate-type","https://slsa.dev/provenance/v1","--deny-self-hosted-runners","--bundle","/proc/self/fd/14/bundle.json","--custom-trusted-root","/proc/self/fd/12","--format","json",NULL};
 char *envp[]={NULL}; ok("before_exact_gh_exec");
 execve(gh,av,envp); die("execve_gh");
}
