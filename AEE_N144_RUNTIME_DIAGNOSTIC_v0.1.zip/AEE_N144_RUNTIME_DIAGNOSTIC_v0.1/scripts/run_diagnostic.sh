#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
EVID=${1:?path to extracted AEE_N144_EXECUTION_EVIDENCE root}
BASE="$EVID/aee_post_build_environment/AEE_POST_BUILD_EXECUTION_ENVIRONMENT_v0.1"
GH="$BASE/work/candidate/tcb/gh"
SUBJ="$BASE/payload/aee_subject.tar"
BUNDLE="$BASE/payload/aee_bundle.sigstore.json"
TR="$BASE/work/candidate/tcb/trusted_root.jsonl"
for f in "$GH" "$SUBJ" "$BUNDLE" "$TR"; do test -f "$f"; done
printf '%s  %s\n' d0a901528411dfc2295253ba4183b99788f99c5901e3a6dda9172089c42d3b85 "$GH" | sha256sum -c -
printf '%s  %s\n' 44e02620034c8c5e3d9de09cc655d60dee2fefabcefb17ad8f068cf4ece9edc4 "$SUBJ" | sha256sum -c -
printf '%s  %s\n' d39c66e8096b77e74fd26c939848fc524652baca646bbc59bae8324d23b80d13 "$BUNDLE" | sha256sum -c -
printf '%s  %s\n' 65ca537f6ed8a47fd0e560c421baa1f6c1efb8b25fc200d8c5c02c0e92eb2b9c "$TR" | sha256sum -c -
gcc -O2 -Wall -Wextra -o "$ROOT/probe" "$ROOT/scripts/probe.c"
sudo "$ROOT/probe" "$GH" "$SUBJ" "$BUNDLE" "$TR" > "$ROOT/gh.stdout" 2> "$ROOT/gh.stderr" || rc=$?
rc=${rc:-0}
printf '{"returncode":%d,"stdout_sha256":"%s","stderr_sha256":"%s"}\n' "$rc" "$(sha256sum "$ROOT/gh.stdout"|awk '{print $1}')" "$(sha256sum "$ROOT/gh.stderr"|awk '{print $1}')" | tee "$ROOT/result.json"
cat "$ROOT/gh.stderr" >&2
cat "$ROOT/gh.stdout"
exit "$rc"
