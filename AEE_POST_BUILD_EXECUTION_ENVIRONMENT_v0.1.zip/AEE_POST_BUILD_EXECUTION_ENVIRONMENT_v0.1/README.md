# AEE POST-BUILD Execution Environment v0.1

Purpose: rerun the exact v0.2.1 implementation candidate, unchanged, on a Linux x86-64 host that can satisfy the frozen namespace/mount preconditions. This package does not access TED and does not rebuild or repair the candidate.

## Hard gate

Run `sudo ./scripts/run_gate.sh` from this directory on an isolated disposable Linux x86-64 VM. The script performs host preflight, exact byte/digest verification, stages the frozen TCB at the exact `/opt/limen-aee/tcb` paths, then executes only N144 first.

N144 is accepted only if the exact candidate returns `PASS_EVIDENCE` with reason `all frozen AEE evidence checks passed`. That result is stronger than the N144 requirement and proves the execution proceeded past the historical gh bundle filename-extension gate, through offline cryptographic verification, claim processing, DER guard and frozen parser.

If N144 does not establish that positive baseline, the script exits nonzero and the 152-case campaign must remain stopped.

## GitHub Actions option

The included `.github/workflows/aee_postbuild_n144.yml` is a convenience wrapper for a disposable Ubuntu runner. It requires this directory to be committed in the repository at `AEE_POST_BUILD_EXECUTION_ENVIRONMENT_v0.1/`. The workflow uses `sudo` because the frozen candidate itself requires kernel namespace/mount operations. Runner capability is not assumed: the preflight remains authoritative and fails closed if the runner cannot satisfy it.

## Matrix limitation deliberately preserved

The controlling matrix contains exactly N001-N152, but it is a semantic negative-test matrix rather than a complete set of concrete mutation fixtures/injection programs. This package therefore does not fabricate implementation-specific test vectors for N001-N152. A full campaign may begin only after N144 PASS and after the concrete case-materialization layer is itself frozen and independently reviewed. This prevents a claimed "152/152" result that was never actually exercised.

No outcome produced by this package authorizes deployment, live TED, end-to-end PERMIT, or authority beyond FINAL_POLICY.
