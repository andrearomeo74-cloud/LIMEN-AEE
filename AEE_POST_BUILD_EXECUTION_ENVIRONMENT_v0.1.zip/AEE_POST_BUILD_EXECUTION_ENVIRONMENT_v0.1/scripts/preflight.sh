#!/usr/bin/env bash
set -euo pipefail
OUT=${1:-preflight.json}
fail=0
[[ "$(uname -s)" == "Linux" ]] || fail=1
[[ "$(uname -m)" == "x86_64" ]] || fail=1
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then fail=1; fi
mnt=0; net=0; tmpfs=0
if unshare -m --propagation private sh -ceu 'd=$(mktemp -d /tmp/aee-preflight-mnt.XXXXXX); trap "umount -l $d 2>/dev/null || true; rmdir $d 2>/dev/null || true" EXIT; mount -t tmpfs -o nosuid,nodev,noexec,size=1m aee-preflight "$d"; mount -o remount,ro,nosuid,nodev,noexec "$d"; touch "$d/x" 2>/dev/null && exit 3 || true; umount "$d"' >/dev/null 2>&1; then mnt=1; tmpfs=1; else fail=1; fi
if unshare -n sh -ceu 'test "$(readlink /proc/self/ns/net)" != "$(readlink /proc/1/ns/net)" || true; ip link >/dev/null 2>&1 || true' >/dev/null 2>&1; then net=1; else fail=1; fi
python3 - "$OUT" "$fail" "$mnt" "$net" "$tmpfs" <<'PY'
import json,platform,os,sys,datetime
out,fail,mnt,net,tmpfs=sys.argv[1:]
d={"timestamp_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"linux":platform.system()=="Linux","machine":platform.machine(),"euid":os.geteuid(),"mount_namespace":mnt=="1","network_namespace":net=="1","tmpfs_mount_and_readonly_remount":tmpfs=="1","result":"PASS" if fail=="0" else "FAIL"}
open(out,"w").write(json.dumps(d,indent=2,sort_keys=True)+"\n")
print(json.dumps(d,sort_keys=True))
PY
exit "$fail"
