#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"
mkdir -p results
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then echo 'Run as root on the isolated test VM.' >&2; exit 2; fi
./scripts/preflight.sh results/PREFLIGHT.json
./scripts/verify_and_stage.py | tee results/VERIFY_AND_STAGE.jsonl
set +e
./scripts/run_n144.py | tee results/N144_console.jsonl
rc=${PIPESTATUS[0]}
set -e
if [[ $rc -ne 0 ]]; then
  printf '%s\n' 'STOP: N144 positive baseline not established. Do not run N001-N152.' | tee results/GATE_STATUS.txt
  exit $rc
fi
printf '%s\n' 'N144_BASELINE_PASS: full 152-case campaign may proceed only with independently materialized case executors preserving the frozen matrix semantics.' | tee results/GATE_STATUS.txt
