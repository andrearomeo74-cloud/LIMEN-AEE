#!/usr/bin/env python3
import hashlib,json,os,struct,subprocess,sys,datetime
from pathlib import Path
root=Path(__file__).resolve().parents[1]
outdir=root/'results/N144'; outdir.mkdir(parents=True,exist_ok=True)
subject=(root/'payload/aee_subject.tar').read_bytes(); bundle=(root/'payload/aee_bundle.sigstore.json').read_bytes()
frame=struct.pack('>Q',len(subject))+subject+struct.pack('>Q',len(bundle))+bundle
exe=root/'work/candidate/bin/aee_verifier'
p=subprocess.run([str(exe)],input=frame,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
(outdir/'stdout.bin').write_bytes(p.stdout); (outdir/'stderr.bin').write_bytes(p.stderr)
try: parsed=json.loads(p.stdout.decode('utf-8'))
except Exception: parsed=None
baseline_pass=isinstance(parsed,dict) and parsed.get('outcome')=='PASS_EVIDENCE' and parsed.get('reason')=='all frozen AEE evidence checks passed'
res={"test_id":"N144","timestamp_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"returncode":p.returncode,"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest(),"parsed":parsed,"baseline_gate":"PASS" if baseline_pass else "FAIL","interpretation":"PASS_EVIDENCE proves execution proceeded beyond gh filename-extension gate through cryptographic verification and all later frozen checks." if baseline_pass else "N144 positive baseline not established; stop before matrix."}
(outdir/'result.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
print(json.dumps(res,sort_keys=True))
sys.exit(0 if baseline_pass else 42)
