# AEE POST-BUILD Execution Environment v0.2

Purpose: execute only N144 against the exact statically authorized AEE implementation candidate v0.2.2, unchanged, on a disposable Linux x86-64 GitHub-hosted runner satisfying the frozen namespace/mount preconditions. This package does not access TED, does not rebuild the candidate, and does not repair any frozen component.

## Authorized scope

The independent static remediation review returned PASS_TO_POST_BUILD_TEST for candidate v0.2.2. That authorization extends only to an isolated N144 rerun. N001-N152 remain blocked until N144 establishes the positive baseline.

Exact candidate ZIP SHA-256: `8c0cfc5ddb15ed7ae46aea0ea88c8d701858b0dcc210406c699a40874e05f818`.
Exact candidate binary SHA-256: `dca0865e8df2df31f2c65d0bbb2693c14ef08d9990848e6f1eca7b3beb801455`.

## Hard gate

Run `sudo ./scripts/run_gate.sh` only on an isolated disposable Linux x86-64 host. The gate performs host preflight, exact package/candidate/fixture/matrix verification, stages the exact frozen TCB, and executes N144 only.

N144 passes only if the exact candidate returns `PASS_EVIDENCE` with reason `all frozen AEE evidence checks passed`. Any other outcome stops the campaign before N001-N152.

## Historical blocker remediation

v0.2.1 failed N144 before gh execution because the post-mount tmpfs root was reopened through `/proc/self/fd/<base>` with `O_NOFOLLOW`, producing ENOTDIR on the GitHub runner. v0.2.2 changes only that post-mount root acquisition to the TCB-created real mountpoint pathname `mp`; the independent static review verified the remediation and returned PASS_TO_POST_BUILD_TEST. This execution package does not assume runtime success.

## Matrix limitation

The frozen matrix remains 152 semantic adversarial cases. This package does not execute or fabricate N001-N152 case materialization. Even after N144 PASS, a concrete case-materialization layer must be frozen and independently reviewed before a full campaign can be claimed.

No result from this package authorizes deployment, live TED access, end-to-end PERMIT, or authority beyond FINAL_POLICY.
