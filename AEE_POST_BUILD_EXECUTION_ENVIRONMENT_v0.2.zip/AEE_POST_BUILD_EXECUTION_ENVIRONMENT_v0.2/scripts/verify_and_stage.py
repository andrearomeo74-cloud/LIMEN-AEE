#!/usr/bin/env python3
import hashlib,json,os,sys,zipfile,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
exp=json.loads((root/'EXPECTED_DIGESTS.json').read_text())
def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def req(ok,msg):
 if not ok: raise SystemExit('VERIFY_FAIL: '+msg)
cz=root/exp['candidate_zip']['path']; req(sha(cz)==exp['candidate_zip']['sha256'],'candidate zip sha256')
for k in ('n144_subject','n144_bundle'):
 p=root/exp[k]['path']; req(p.stat().st_size==exp[k]['bytes'],f'{k} size'); req(sha(p)==exp[k]['sha256'],f'{k} sha256')
mp=root/exp['matrix']['path']; req(sha(mp)==exp['matrix']['sha256'],'matrix sha256')
m=json.loads(mp.read_text()); req(m.get('count')==152 and len(m.get('tests',[]))==152,'matrix count')
ids=[x.get('id') for x in m['tests']]; req(ids==[f'N{i:03d}' for i in range(1,153)],'matrix ids')
stage=root/'work/candidate'; shutil.rmtree(stage.parent,ignore_errors=True); stage.mkdir(parents=True)
with zipfile.ZipFile(cz) as z: z.extractall(stage)
req(sha(stage/'bin/aee_verifier')==exp['candidate_binary']['sha256'],'candidate binary sha256')
# candidate's own manifest: exact candidate format is {algorithm, entries:[...]}
man=json.loads((stage/'SHA256SUMS.json').read_text())
req(isinstance(man,dict),'candidate manifest top-level shape')
req(man.get('algorithm')=='SHA-256','candidate manifest algorithm')
entries=man.get('entries')
req(isinstance(entries,list),'candidate manifest entries shape')
seen=set()
for e in entries:
 req(isinstance(e,dict),'candidate manifest entry shape')
 req(set(e.keys())=={'path','sha256','size'},f'candidate manifest entry keys {e.get("path","?")}')
 rel=e['path']; req(isinstance(rel,str) and rel and not rel.startswith('/') and '..' not in Path(rel).parts,f'candidate manifest path {rel!r}')
 req(rel not in seen,f'duplicate candidate manifest path {rel}'); seen.add(rel)
 req(isinstance(e['sha256'],str) and len(e['sha256'])==64 and all(c in '0123456789abcdef' for c in e['sha256']),f'candidate manifest sha shape {rel}')
 req(isinstance(e['size'],int) and e['size']>=0,f'candidate manifest size shape {rel}')
 fp=stage/rel; req(fp.is_file(),f'missing {rel}'); req(fp.stat().st_size==e['size'],f'manifest size {rel}'); req(sha(fp)==e['sha256'],f'manifest sha {rel}')
# The candidate manifest intentionally excludes only SHA256SUMS.json itself.
actual={str(x.relative_to(stage)) for x in stage.rglob('*') if x.is_file() and x.name!='SHA256SUMS.json'}
req(seen==actual,'candidate manifest coverage')
# stage exact TCB to fixed runtime path
opt=Path('/opt/limen-aee/tcb'); opt.mkdir(parents=True,exist_ok=True)
for name in ('gh','trusted_root.jsonl','extract_verified_deployment_env_linux_x86_64'):
 src=stage/'tcb'/name; dst=opt/name
 shutil.copyfile(src,dst); os.chmod(dst,0o555 if name!='trusted_root.jsonl' else 0o444)
 req(sha(dst)==sha(src),f'/opt staged identity {name}')
os.chmod(stage/'bin/aee_verifier',0o555)
print(json.dumps({'result':'PASS','stage':str(stage),'candidate_binary_sha256':sha(stage/'bin/aee_verifier'),'tcb_path':str(opt)},sort_keys=True))
